package com.tianchuangya.islandsync

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

/**
 * 配置页：Gitee 仓库信息 + 通知使用权授权 + 启动常驻服务 + 测试推送。
 */
class MainActivity : Activity() {

    private lateinit var ownerEdit: EditText
    private lateinit var repoEdit: EditText
    private lateinit var branchEdit: EditText
    private lateinit var pathEdit: EditText
    private lateinit var tokenEdit: EditText
    private lateinit var watchEdit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPostNotificationPermissionIfNeeded()

        val prefs = getSharedPreferences(IslandNotificationListener.PREFS, MODE_PRIVATE)
        val padding = (16 * resources.displayMetrics.density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        fun addField(hintRes: Int, value: String): EditText {
            val edit = EditText(this)
            edit.hint = getString(hintRes)
            edit.setText(value)
            edit.setSingleLine(true)
            layout.addView(edit)
            return edit
        }

        ownerEdit = addField(R.string.hint_owner, prefs.getString("gitee_owner", "") ?: "")
        repoEdit = addField(R.string.hint_repo, prefs.getString("gitee_repo", "") ?: "")
        branchEdit = addField(R.string.hint_branch, prefs.getString("gitee_branch", "master") ?: "master")
        pathEdit = addField(R.string.hint_path, prefs.getString("gitee_path", "island.json") ?: "island.json")
        tokenEdit = addField(R.string.hint_token, prefs.getString("gitee_token", "") ?: "")
        watchEdit = addField(R.string.hint_watch, prefs.getString("watch_apps", "wechat,qq") ?: "wechat,qq")

        fun addButton(textRes: Int, onClick: () -> Unit): Button {
            val button = Button(this)
            button.text = getString(textRes)
            button.setOnClickListener { onClick() }
            layout.addView(button)
            return button
        }

        addButton(R.string.save) {
            prefs.edit()
                .putString("gitee_owner", ownerEdit.text.toString().trim())
                .putString("gitee_repo", repoEdit.text.toString().trim())
                .putString("gitee_branch", branchEdit.text.toString().trim().ifEmpty { "master" })
                .putString("gitee_path", pathEdit.text.toString().trim().ifEmpty { "island.json" })
                .putString("gitee_token", tokenEdit.text.toString().trim())
                .putString("watch_apps", watchEdit.text.toString().trim().ifEmpty { "wechat,qq" })
                .apply()
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
        }

        addButton(R.string.grant_listener) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        addButton(R.string.start_service) {
            val serviceIntent = Intent(this, IslandForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, R.string.service_started, Toast.LENGTH_SHORT).show()
        }

        addButton(R.string.test_push) {
            val owner = ownerEdit.text.toString().trim()
            val repo = repoEdit.text.toString().trim()
            if (owner.isEmpty() || repo.isEmpty()) {
                Toast.makeText(this, R.string.need_repo, Toast.LENGTH_SHORT).show()
                return@addButton
            }
            prefs.edit()
                .putString("gitee_owner", owner)
                .putString("gitee_repo", repo)
                .putString("gitee_branch", branchEdit.text.toString().trim().ifEmpty { "master" })
                .putString("gitee_path", pathEdit.text.toString().trim().ifEmpty { "island.json" })
                .putString("gitee_token", tokenEdit.text.toString().trim())
                .apply()
            Toast.makeText(this, R.string.pushing, Toast.LENGTH_SHORT).show()
            Thread {
                val branch = branchEdit.text.toString().trim().ifEmpty { "master" }
                val path = pathEdit.text.toString().trim().ifEmpty { "island.json" }
                val token = tokenEdit.text.toString().trim()
                val test = org.json.JSONObject()
                    .put("updated", System.currentTimeMillis())
                    .put("notifications", org.json.JSONArray()
                        .put(org.json.JSONObject()
                            .put("id", "test-${System.currentTimeMillis()}")
                            .put("app", "wechat")
                            .put("title", "灵动岛测试")
                            .put("text", "如果你在电脑上看到这条弹窗，链路就通了！")
                            .put("ts", System.currentTimeMillis())))
                val ok = GiteeClient.putContent(
                    owner, repo, path, branch, token, test.toString(),
                )
                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (ok) R.string.push_ok else R.string.push_failed,
                        Toast.LENGTH_LONG,
                    ).show()
                }
            }.start()
        }

        addButton(R.string.open_gitee) {
            val owner = ownerEdit.text.toString().trim()
            val repo = repoEdit.text.toString().trim()
            if (owner.isNotEmpty() && repo.isNotEmpty()) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://gitee.com/$owner/$repo")))
            }
        }

        setContentView(layout)
    }

    private fun requestPostNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }
}
