# Island Sync · 灵动岛手机↔电脑互通（第一版）

手机系统通知实时同步到电脑，以"灵动岛"药丸弹窗展示；剪贴板双向互通。
中转站是你自己的 Gitee 私有仓库 —— 无需公网 IP、无需自建服务器，国内直连。

## 架构

```
┌──────────┐  通知监听(NotificationListenerService)   ┌──────────────┐
│ 手机 APK │ ──── 合并 1.5s → PUT island.json ───────▶ │              │
└──────────┘                                           │  Gitee 仓库  │
                                                       │ island.json  │
┌────────────────────────────────┐                     │              │
│ 电脑 GNOME 扩展 island-sync@local │ ◀── 每 10s GET ─── │              │
│  · 顶部灵动岛药丸（可展开卡片）   │                     └──────────────┘
│  · 点击「打开微信/QQ」启动应用    │
│  · 剪贴板：手机→电脑自动；       │
│    电脑→手机在面板菜单手动推送   │
└────────────────────────────────┘
```

## 第一步 · 准备 Gitee 仓库

1. 在 Gitee 新建一个**私有**仓库（例如 `island-sync`，分支 `master`）。
2. 头像 → 设置 → 私人令牌 → 生成新令牌（勾选 `projects` 权限），复制保存。
3. 把本目录的 `island.json.example` 内容手动创建为仓库根目录的 `island.json`
   （或者直接用手机 App 的「发送测试通知」首次自动创建）。

## 第二步 · 电脑端（GNOME 扩展）

```bash
bash ~/桌面/unbuntu美化/island-sync/pc-extension/install.sh
```

装完后：扩展管理器 → Island Sync → 设置，填入：

| 字段 | 说明 |
|---|---|
| Gitee 用户名 / 仓库名 | 例如 `tianchuangya / island-sync` |
| 分支 / 文件路径 | 默认 `master` / `island.json` |
| Gitee 私人令牌 | 第一步生成的 token |
| 轮询间隔 | 默认 10 秒（越短越实时，越高耗电） |
| launch-map | 通知点击后打开应用的命令，默认 `{"wechat": "gtk-launch wechat", "qq": "gtk-launch qq"}` |

如果扩展设置界面暂时没出现，可以直接用命令写入配置：

```bash
SCHEMA_DIR="$HOME/.local/share/gnome-shell/extensions/island-sync@local/schemas"
GSETTINGS_SCHEMA_DIR="$SCHEMA_DIR" gsettings set org.gnome.shell.extensions.island-sync gitee-owner '你的Gitee用户名'
GSETTINGS_SCHEMA_DIR="$SCHEMA_DIR" gsettings set org.gnome.shell.extensions.island-sync gitee-repo '你的仓库名'
GSETTINGS_SCHEMA_DIR="$SCHEMA_DIR" gsettings set org.gnome.shell.extensions.island-sync gitee-token '你的私人令牌'
GSETTINGS_SCHEMA_DIR="$SCHEMA_DIR" gsettings set org.gnome.shell.extensions.island-sync gitee-branch 'master'
GSETTINGS_SCHEMA_DIR="$SCHEMA_DIR" gsettings set org.gnome.shell.extensions.island-sync gitee-path 'island.json'
```

修改扩展文件后，推荐按 `Alt+F2 → r → 回车` 重新加载 GNOME Shell。不要手动运行
`gnome-shell --replace`，那样容易把桌面会话环境搞乱。

装好后顶部面板出现手机图标菜单：立即同步 / 显示测试灵动岛 / 推送剪贴板到手机 / 上次同步状态。

「显示测试灵动岛」不依赖手机和 Gitee，用来先检查电脑端 UI 是否能正常弹出、展开和点击。

通知到达时屏幕顶部居中弹出玻璃药丸（应用 + 标题 + 摘要），点击展开卡片：
**打开微信 / 打开QQ / 复制内容 / 关闭**。

## 第三步 · 手机端（APK 构建）

`phone-android/` 是完整的 Android Studio 工程（Kotlin，无第三方依赖）：

Codex 已经构建好的 debug APK 放在：

```text
~/桌面/unbuntu美化/apk/island-sync-debug.apk
```

可以直接把这个 APK 发到手机安装。

1. Android Studio → Open 打开 `phone-android/`，等 Gradle 同步完成；
2. `Build → Build APK(s)` 生成 `app/build/outputs/apk/debug/app-debug.apk`；
3. 安装到手机，打开 App：
   - 填写 Gitee 用户名 / 仓库名 / 令牌 → 保存；
   - 点 **① 授权读取系统通知**（设置里允许「灵动岛同步」）；
   - 点 **② 启动常驻后台服务**（前台服务 + 开机自启，建议在最近任务里锁 定）；
   - 点 **③ 发送测试通知** —— 电脑几秒内应弹出灵动岛。

之后微信/QQ 的每条通知都会自动同步（1.5 秒合并，避免连发刷屏）。

### 剪贴板互通

* **手机 → 电脑**：手机上复制内容后，从分享菜单选「灵动岛同步」；电脑端轮询到
  `clipboard.from=phone` 的新条目后自动写入电脑剪贴板并通知。
  （Android 10+ 禁止后台读剪贴板，所以走系统分享入口，这是官方限制。）
* **电脑 → 手机**：面板菜单「推送剪贴板到手机」，手机端下次拉取即可在
  App 里看到/复制（后续版本可在通知里加"复制"操作按钮）。

## 已知限制与后续计划

* 大文件（>100MB）传输：第一版只做通知+文本剪贴板。图片等小文件可走
  Gitee 附件或 issue 评论区；大文件建议后续换 SFTP/WebDAV 直连或局域网 mDNS 方案。
* 实时性受轮询间隔限制（Gitee 无推送回调）；把电脑端轮询调到 5s 已经接近即时。
* 微信 PC 端启动命令因安装方式而异：官方 deb 桌面项通常可用 `gtk-launch wechat`，
  Flatpak 可改成 `flatpak run com.tencent.WeChat`，可在 launch-map 里自行调整。
* 手机端 JSON 写入是"读-改-写"，两台设备同时写可能冲突，App 内置了 2s 重试。

## 文件结构

```
island-sync/
├── pc-extension/            # 电脑端 GNOME 扩展
│   ├── island-sync@local/   #   扩展本体（extension.js + schema + 样式）
│   └── install.sh
├── phone-android/           # 手机端 Android Studio 工程（Kotlin）
├── island.json.example      # Gitee 仓库数据文件格式
└── README.md
```
